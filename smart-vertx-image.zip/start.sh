#!/bin/bash

java -jar -javaagent:/user/lib/arthas/arthas-agent.jar app.jar --add-opens  java.base/java.lang=ALL-UNNAMED